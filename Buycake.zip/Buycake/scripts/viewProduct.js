
function loadProducts() {
    if ((window.localStorage.getItem("products")) != null) {
        var product = JSON.parse(window.localStorage.getItem("products"));
        var brownieContainer = document.getElementById('idBrownie');
        product.forEach(function (c) {
            var divTag = document.createElement('div');
            divTag.classList.add("menu", "grid_4");
            var pTag = document.createElement('p');
            var aTag = document.createElement('a');
            aTag.classList.add("menu", "grid_4", "alpha");

            var imgTag = document.createElement('img');
            imgTag.setAttribute('src', c.image);
            imgTag.setAttribute('width', "220");
            imgTag.setAttribute('height', "120");

            aTag.appendChild(imgTag);

            var brTag = document.createElement('br');
            pTag.appendChild(aTag);
            pTag.appendChild(brTag);

            var aTitleTag = document.createElement('a');
            aTitleTag.innerText = c.des;
            pTag.appendChild(aTitleTag);
            divTag.appendChild(pTag);

            name = window.sessionStorage.getItem("Name");
            if (name === null) {

                return;
            }

            if (name === "Admin") {
                var buttonEditTag = document.createElement('button');
                buttonEditTag.innerText = 'Edit Product';
                buttonEditTag.setAttribute('onclick', `editProductRedirect(${c.id})`);
                divTag.appendChild(buttonEditTag);
                brownieContainer.appendChild(divTag);

            
                var buttonEditTag = document.createElement('button');
                buttonEditTag.innerText = 'Delete Product';
                buttonEditTag.setAttribute('onclick', `editProductRedirect(${c.id})`);
                divTag.appendChild(buttonEditTag);
                brownieContainer.appendChild(divTag);
            } else {
                var buttonEditTag = document.createElement('button');
                buttonEditTag.innerText = 'Checkout Product';
                buttonEditTag.setAttribute('onclick', `shoppingCartroductRedirect(${c.id})`);
                divTag.appendChild(buttonEditTag);
                brownieContainer.appendChild(divTag);
            }    

        });
    }
}

function editProductRedirect(id) {
    window.location.href = "file:///C:/Users/User/Desktop/Buycake/editProduct.html?id=" + id;
}

function shoppingCartroductRedirect(id) {
    window.location.href = "file:///C:/Users/User/Desktop/Buycake/shoppingcart.html?id=" + id;
}



function createDiv() {
    var c = JSON.parse(window.localStorage.getItem("products"));
    console.log("type" + c.length);
    //for (var i = 0; i < Object.keys(data).length; i++) {
    for (i; i < c.length; i++) {
        var iDiv = document.createElement('div');
        iDiv.id = i;
        // iDiv.className = 'block';
        var img = document.createElement('img');
        // iDiv.style.backgroundImage="url('https://www.fnordware.com/superpng/pnggrad16rgb.png')";
        img.src = c[i]['image'];
        img.style.width = "250px";
        img.style.height = "250px";
        iDiv.style.display = "inline-block";
        iDiv.appendChild(img);
        var close = document.createElement('input');
        close.type = "button";

        //close.style.backgroundColor="red";
        iDiv.style.position = "relative";
        close.style.position = "absolute";
        close.style.width = "26px";
        close.style.height = "26px";
        close.style.backgroundImage = "url('icon.png')";
        iDiv.appendChild(close);

        close.onclick = function () {
            console.log("click");
            iDiv.remove();
        }
        var edit = document.createElement('div');
        var editobuttn = document.createElement('input');
        editobuttn.type = "button";
        editobuttn.value = "edit";
        edit.value = i;
        edit.style.visibility = "hidden";
        iDiv.appendChild(edit);
        iDiv.appendChild(editobuttn);
        editobuttn.onclick = function () {

            submit.hidden = true;
            editbtn.hidden = false;
            console.log("edit" + edit.value);
            var editprdct = edit.value;
            productid.value = data[editprdct]['id'];
            productname.value = data[editprdct]['name'];
            des.value = data[editprdct]['des'];
            price.value = data[editprdct]['price'];
            image.value = data[editprdct]['image'];

            editbtn.onclick = function () {
                event.preventDefault();
                var b = validation();
                if (b == true) {
                    data[editprdct]['id'] = productid.value;
                    data[editprdct]['name'] = productname.value
                    data[editprdct]['des'] = des.value;
                    data[editprdct]['price'] = price.value;
                    data[editprdct]['image'] = image.value;

                    document.getElementById("form").reset();
                    var parent = document.getElementById(editprdct);
                    parent.getElementsByTagName('img')[0].src = data[editprdct]['image'];
                    parent.getElementsByTagName('div')[1].innerHTML = "Name:  " + data[editprdct]['name'];
                    parent.getElementsByTagName('div')[2].innerHTML = "Price:  " + data[editprdct]['price'];
                    parent.getElementsByTagName('div')[3].innerHTML = "Description:  " + data[editprdct]['des'];
                    submit.hidden = false;
                    editbtn.hidden = true;
                }
            }

        }
        var namelabel = document.createElement("div");
        namelabel.innerHTML = "Name:  " + c[i]['name'];
        iDiv.appendChild(namelabel);
        var pricelabel = document.createElement("div");
        pricelabel.innerHTML = "Price  :" + c[i]['price'];
        iDiv.appendChild(pricelabel);
        var deslabel = document.createElement("div");
        deslabel.innerHTML = "Description  :" + c[i]['des'];
        iDiv.appendChild(deslabel);

    }
    var div = document.getElementById('cont');
    div.appendChild(iDiv);
    document.getElementById("form").reset();
    if (window.localStorage.getItem("products") != null) {
        document.getElementById('clearbtn').style.visibility = "visible";
    }
    // i++;

}
