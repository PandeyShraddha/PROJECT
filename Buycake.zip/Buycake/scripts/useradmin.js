function register() {
    event.preventDefault();
    
    var detailName = document.getElementById("userDetailName").value;
    var username = document.getElementById("userName").value;
    var email = document.getElementById("userEmail").value;
    var password = document.getElementById("userPassword").value;
    var repassword = document.getElementById("userRepassword").value;
    document.getElementById("register_error_name").innerHTML = "";
    document.getElementById("register_error_username").innerHTML = "";
    document.getElementById("register_error_email").innerHTML = "";
    document.getElementById("register_error_password").innerHTML = "";
    document.getElementById("register_error_repassword").innerHTML = "";
    //document.getElementById("user_error").innerHTML = "";
    //document.getElementById("email_error").innerHTML = "";
    var emailresult;
    
    if (detailName == "") {
        document.getElementById("register_error_name").innerHTML = "Please enter name";
        return false;
    }
    if (username == "") {
        //alert("username cannot empty");
        document.getElementById("register_error_username").innerHTML = "Please enter username";
        return false;
    }
    if (email == "") {
        document.getElementById("register_error_email").innerHTML = "Please enter email";
        return false;
    }
    else {
        emailresult = ValidateEmail(email);
    }

    if (password == "") {
        document.getElementById("register_error_password").innerHTML = "Please enter password";
        return false;
    }

    if (repassword == "") {
        document.getElementById("register_error_repassword").innerHTML = "Please enter repassword";
        return false;
    }

    if (password != repassword) {
        document.getElementById("register_error_repassword").innerHTML = "Password and Re-Password not matching";
        return false;
    }

    if (detailName != "" && email != "" && password != "" && username != "" && emailresult == true) {
        if (window.localStorage.getItem(username) != null) {
            var exist_user = JSON.parse(window.localStorage.getItem(username));
            if (username == exist_user.username) {
                document.getElementById("register_error_user").innerHTML = "User Already Exist";
                return false;
            }
        }
        var person = { 'username': username, 'password': password, 'Name': detailName, 'email': email };
        window.localStorage.setItem(username, JSON.stringify(person));
        document.getElementById("registerForm").reset();
    }
    else {

    }

}
function ValidateEmail(inputText) {
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (inputText.match(mailformat)) {
        //document.form1.text1.focus();
        return true;
    }
    else {
        document.getElementById("email_error").innerHTML = "You have entered an invalid email address!";
        //document.form1.text1.focus();
        return false;
    }
}

function forgotpassword() {
    event.preventDefault();
    window.location.href = "forgotpassword.html";
}

function showpswd() {

}

function login_user() {
    event.preventDefault();
    document.getElementById("login").style.visibility = "hidden";
    document.getElementById("loginform").style.visibility = "visible";
    document.getElementById("registerform").style.visibility = "hidden";

}

function login() {
    document.getElementById("login_error_username").innerHTML = "";
    document.getElementById("login_error_password").innerHTML = "";
    
    event.preventDefault();
    var user_name = document.getElementById("login_username").value;
    var user_pswd = document.getElementById("login_password").value;
    var user;

    if (user_name === "") {
        document.getElementById("login_error_username").innerHTML = "Please enter username";
        return false;
    }
    if (user_pswd === "") {
        document.getElementById("login_error_password").innerHTML = "Please enter password";
        return false;
    }
    if (user_name === "" && user_pswd === "") {
        document.getElementById("login_error_username").innerHTML = "Please enter username and password";
        document.getElementById("login_error_password").innerHTML = "Please enter username and password";
        return false;
    }

    if (user_name == "admin" && user_pswd == "admin") {
        window.sessionStorage.setItem("Name", "Admin");
        window.location.href = "product-overview.html";
    }
    else {
        if (window.localStorage.getItem(user_name) != null) {
            user = JSON.parse(window.localStorage.getItem(user_name));

            var usrname = user.username;
            var pswd = user.password;
            var name = user.name;
            console.log("userr" + usrname);
            console.log("succ" + pswd);
            if (user_name == usrname && user_pswd == pswd) {
                window.sessionStorage.setItem("username", user_name);
                window.sessionStorage.setItem("password", user_pswd);
                window.sessionStorage.setItem("Name", name);
                window.location.href = "product-overview.html"
                //alert("login success");
            }
            else {
                document.getElementById("login_error").innerHTML = "Either username or pswd is incorrect";

                // alert("either username or pswd incorrect");
            }
        }
        else {
            document.getElementById("login_error").innerHTML = "User not found";

        }
    }

}

function logOut()
{
    window.sessionStorage.clear();
    window.location.href = "file:///C:/Users/User/Desktop/Buycake/index.html";
}

