var name = window.sessionStorage.getItem("Name");

//document.getElementById("logduser").innerHTML = "Welcome  " + name;
var products = [];
function addproduct() {
    event.preventDefault();
    var getproduct;
    var productid = document.getElementById("pid");
    var productname = document.getElementById("pname");
    var des = document.getElementById("pdes");
    var price = document.getElementById("pprice");
    var image = document.getElementById("pimage");

    //var d = validation();

    var d = true;

    if (d == true) {

        if (window.localStorage.getItem("products") == null) {
            window.localStorage.setItem("products", JSON.stringify([]));
        }

        var newData = { 'id': productid.value, 'name': productname.value, 'des': des.value, 'price': price.value, 'image': image.value };
        getproduct = JSON.parse(window.localStorage.getItem("products"));
        getproduct.push(newData);
        window.localStorage.setItem("products", JSON.stringify(getproduct));

        document.getElementById("productForm").reset();
    }

    window.location.href = "file:///C:/Users/User/Desktop/Buycake/product-overview.html";
}


function validation() {
    if (productid.value == "") {
        document.getElementById("pid_error").innerHTML = "Please enter product id";
        //  document.getElementById("pid_error").focus();
        return false;
    }
    else {
        document.getElementById("pid_error").innerHTML = "";
    }
    if (productname.value == "") {
        document.getElementById("pname_error").innerHTML = "Please enter product name";
        //  document.getElementById("pname_error").focus();
        return false;
    }
    else {
        document.getElementById("pname_error").innerHTML = "";
    }
    return true;
}

function logout() {
    // alert("hii");
    window.sessionStorage.clear();
    window.location.href = "index.html";
}

