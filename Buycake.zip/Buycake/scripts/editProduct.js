var name = window.sessionStorage.getItem("Name");


window.onload = function () {
    editProductId = window.location.search.split('=')[1];
    allProducts = JSON.parse(window.localStorage.getItem("products"));
    var productDetails = allProducts.find(function (item) { return item.id === editProductId });
    document.getElementById("pid").value = productDetails.id;
    document.getElementById("pname").value = productDetails.name;
    document.getElementById("pdes").value = productDetails.des;
    document.getElementById("pprice").value = productDetails.price;
    document.getElementById("pimage").value = productDetails.image;
};

function deleteProduct(){
    event.preventDefault();
    var allProducts;
    var productid = document.getElementById("pid").value;
    var index;
    allProducts = JSON.parse(window.localStorage.getItem("products"));

    for (index=0; index < allProducts.length; index++) {
        if (allProducts[index].id === productid) {
            break;
        }
    }
    
    if (index <= allProducts.length - 1)  {
        allProducts.splice(index, 1);
        localStorage.setItem('products', JSON.stringify(allProducts));
    }    

    window.location.href = "file:///C:/Users/User/Desktop/Buycake/product-overview.html";

}

function editProduct() {
    event.preventDefault();
    var getproduct;
    var productid = document.getElementById("pid");
    var productname = document.getElementById("pname");
    var des = document.getElementById("pdes");
    var price = document.getElementById("pprice");
    var image = document.getElementById("pimage");
    var editProductId = window.location.search.split('=')[1];

    //var d = validation();

    var d = true;

    if (d == true) {
        allProducts = JSON.parse(window.localStorage.getItem("products"));
        var productDetails = allProducts.find(function (item) { return item.id === editProductId });

        productDetails['name']  = productname.value;
        productDetails['des']   = des.value;
        productDetails['price'] = price.value;
        productDetails['image'] = image.value;
        productDetails['id']    = productid.value;

        window.localStorage.setItem("products", JSON.stringify(allProducts));

    }

    window.location.href = "file:///C:/Users/User/Desktop/Buycake/product-overview.html";
}


function validation() {
    if (productid.value == "") {
        document.getElementById("pid_error").innerHTML = "Please enter product id";
        //  document.getElementById("pid_error").focus();
        return false;
    }
    else {
        document.getElementById("pid_error").innerHTML = "";
    }
    if (productname.value == "") {
        document.getElementById("pname_error").innerHTML = "Please enter product name";
        //  document.getElementById("pname_error").focus();
        return false;
    }
    else {
        document.getElementById("pname_error").innerHTML = "";
    }
    return true;
}

function logout() {
    // alert("hii");
    window.sessionStorage.clear();
    window.location.href = "index.html";
}

